const wrapper_element = document.querySelector("#ticker .swiper-wrapper");

const ticker_items = document.querySelectorAll(".swiper-slide");
let translate_value;
let json_data;
let swiper_instance;

// below is the code to stop ticker when mouse is over
wrapper_element.addEventListener("mouseover", () => {
  const current_transform = window.getComputedStyle(wrapper_element).transform;
  wrapper_element.style.transitionDuration = "0ms";
  wrapper_element.style.transitionDelay = "0ms";
  wrapper_element.style.transform = current_transform;
});

wrapper_element.addEventListener("mouseout", () => {
  // Resume the transition
  wrapper_element.style.transitionDuration = `${swiper_instance.passedParams.speed}ms`;
  wrapper_element.style.transitionDelay = " ";
  wrapper_element.style.transform = `translate3d(${swiper_instance.translate}px, 0px, 0px)`;
});

const fetchData = async () => {
  await fetch("../npm-ticker/data/data.json")
    .then((response) => response.json())
    .then((data) => {
      json_data = data;
      json_data.forEach((item, index) => {
        wrapper_element.innerHTML += `
          <div class="swiper-slide">
            <div class="swiper-ticker">
              <img src=${item.imageUrl} class="aws" alt="" id=${item.id}>
              <p>${item.description}</p>
            </div>
          </div>
        `;
      });
      // initializing swiper only after fetching data
      swiper_instance = new Swiper(".mySwiper", {
        slidesPerView: "3",
        spaceBetween: 0,
        loop: true,
        autoplay: {
          delay: 0,
          disableOnInteraction: false,
          pauseOnMouseEnter: true,
        },
        speed: 4500,
        touchStartPreventDefault: false,
      });
    })
    .catch((error) => {
      console.log(error);
    });
};

// fetching the data
fetchData();
